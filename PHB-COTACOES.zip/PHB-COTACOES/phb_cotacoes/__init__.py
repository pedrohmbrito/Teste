# phb_cotacoes/__init__.py

# Este arquivo pode ser deixado vazio ou pode conter inicializações
# específicas se for necessário para o projeto.

