python manage.py startapp base
python manage.py startapp triagem
python manage.py startapp cotacao
