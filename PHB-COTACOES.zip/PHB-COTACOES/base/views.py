# base/views.py
# Este arquivo pode ser deixado em branco ou você pode criar views aqui se necessário.
