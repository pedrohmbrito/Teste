# base/admin.py
from django.contrib import admin
from .models import Produto, Fornecedor

# Registra os modelos para que apareçam no admin do Django
admin.site.register(Produto)
admin.site.register(Fornecedor)
