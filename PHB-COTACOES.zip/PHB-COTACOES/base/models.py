# base/models.py
from django.db import models

class Produto(models.Model):
    descricao = models.TextField()  # Descrição do produto
    unidade = models.CharField(max_length=20, blank=True, null=True)  # Unidade de medida
    marca = models.CharField(max_length=100, blank=True, null=True)  # Marca do produto
    modelo = models.CharField(max_length=100, blank=True, null=True)  # Modelo do produto

    def __str__(self):
        return self.descricao[:100]  # Retorna uma versão curta da descrição como string de exibição

class Fornecedor(models.Model):
    nome = models.CharField(max_length=255)  # Nome do fornecedor
    cnpj = models.CharField(max_length=18, blank=True, null=True)  # CNPJ do fornecedor
    email = models.EmailField(blank=True, null=True)  # Email do fornecedor
    telefone = models.CharField(max_length=20, blank=True, null=True)  # Telefone do fornecedor
    endereco = models.TextField(blank=True, null=True)  # Endereço do fornecedor

    def __str__(self):
        return self.nome  # Retorna o nome do fornecedor
