# base/forms.py
from django import forms
from .models import Produto, Fornecedor

# Formulário para o modelo Produto
class ProdutoForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = ['descricao', 'unidade', 'marca', 'modelo']

# Formulário para o modelo Fornecedor
class FornecedorForm(forms.ModelForm):
    class Meta:
        model = Fornecedor
        fields = ['nome', 'cnpj', 'email', 'telefone', 'endereco']
