# base/tests.py
from django.test import TestCase
from .models import Produto, Fornecedor

class ProdutoModelTest(TestCase):
    def test_create_produto(self):
        produto = Produto.objects.create(descricao="Produto Teste", unidade="unidade", marca="Marca X", modelo="Modelo Y")
        self.assertEqual(produto.descricao, "Produto Teste")
        self.assertEqual(produto.unidade, "unidade")
        self.assertEqual(produto.marca, "Marca X")
        self.assertEqual(produto.modelo, "Modelo Y")

class FornecedorModelTest(TestCase):
    def test_create_fornecedor(self):
        fornecedor = Fornecedor.objects.create(nome="Fornecedor Teste", cnpj="00.000.000/0001-00", email="fornecedor@teste.com", telefone="123456789", endereco="Rua Teste, 123")
        self.assertEqual(fornecedor.nome, "Fornecedor Teste")
        self.assertEqual(fornecedor.cnpj, "00.000.000/0001-00")
        self.assertEqual(fornecedor.email, "fornecedor@teste.com")
        self.assertEqual(fornecedor.telefone, "123456789")
        self.assertEqual(fornecedor.endereco, "Rua Teste, 123")
