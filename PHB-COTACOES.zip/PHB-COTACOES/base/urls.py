from django.urls import path

urlpatterns = [
    # (ainda vazio ou com views simples)
]
