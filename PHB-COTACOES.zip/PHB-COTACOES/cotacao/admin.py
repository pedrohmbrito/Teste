from django.contrib import admin
from .models import Cotacao, ItemCotado

admin.site.register(Cotacao)
admin.site.register(ItemCotado)

