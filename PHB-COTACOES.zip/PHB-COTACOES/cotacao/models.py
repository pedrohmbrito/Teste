from django.db import models
from django.contrib.auth.models import User
from triagem.models import ItemTriado

class Cotacao(models.Model):
    numero = models.AutoField(primary_key=True)
    data_criacao = models.DateTimeField(auto_now_add=True)
    usuario = models.ForeignKey(User, on_delete=models.PROTECT)
    observacoes = models.TextField(blank=True, null=True)

    def __str__(self):
        return f'Cotação #{self.numero} - {self.data_criacao.strftime("%d/%m/%Y %H:%M")}'

class ItemCotado(models.Model):
    cotacao = models.ForeignKey(Cotacao, on_delete=models.CASCADE, related_name='itens')
    item_triagem = models.ForeignKey(ItemTriado, on_delete=models.PROTECT)

    def __str__(self):
        return f'Item da Cotação #{self.cotacao.numero} - {self.item_triagem.descricao[:50]}'
