from django.shortcuts import render, get_object_or_404
from .models import Cotacao

def listar_cotacoes(request):
    cotacoes = Cotacao.objects.all().order_by('-data_criacao')
    return render(request, 'cotacao/lista_cotacoes.html', {'cotacoes': cotacoes})

def detalhar_cotacao(request, numero):
    cotacao = get_object_or_404(Cotacao, numero=numero)
    itens = cotacao.itens.select_related('item_triagem')
    return render(request, 'cotacao/detalhe_cotacao.html', {
        'cotacao': cotacao,
        'itens': itens,
    })
