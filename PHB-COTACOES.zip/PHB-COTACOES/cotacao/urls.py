from django.urls import path
from .views import listar_cotacoes, detalhar_cotacao

urlpatterns = [
    path('', listar_cotacoes, name='listar_cotacoes'),
    path('<int:numero>/', detalhar_cotacao, name='detalhar_cotacao'),
]
