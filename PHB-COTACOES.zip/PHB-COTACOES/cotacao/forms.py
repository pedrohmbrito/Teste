# cotacao/forms.py
from django import forms
from .models import Cotacao
from base.models import Produto

class CriarCotacaoForm(forms.ModelForm):
    class Meta:
        model = Cotacao
        fields = ['titulo', 'observacoes']

class SelecionarProdutosForm(forms.Form):
    produtos = forms.ModelMultipleChoiceField(
        queryset=Produto.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=True
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for produto in self.fields['produtos'].queryset:
            self.fields[f'quantidade_{produto.id}'] = forms.DecimalField(
                label=f'Qtd para "{produto.descricao[:40]}..."',
                min_value=0.1
            )
