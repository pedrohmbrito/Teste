# cotacao/__init__.py
# Este arquivo pode ser deixado vazio.
