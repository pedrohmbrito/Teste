import pandas as pd
from .models import ItemTriado

def importar_planilha(caminho_arquivo):
    df = pd.read_excel(caminho_arquivo)

    itens_salvos = []

    for _, linha in df.iterrows():
        item = ItemTriado(
            descricao=linha.get('Descrição', ''),
            unidade=linha.get('Unidade', ''),
            quantidade=linha.get('Qtd', 0),
            grupo='',
            subgrupo='',
            objeto='',
            marca='',
            fabricante='',
            unidade_medida='',
            campo_dinamico_1='',
            campo_dinamico_2='',
            responsavel_triagem=''
        )
        item.save()
        itens_salvos.append(item)

    return itens_salvos
