from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .utils import importar_planilha
from .models import ItemTriado
from cotacao.models import Cotacao, ItemCotado
import pandas as pd


@login_required
def upload_planilha(request):
    if request.method == 'POST':
        arquivo = request.FILES.get('arquivo')

        if arquivo:
            with open('temp_planilha.xlsx', 'wb+') as destino:
                for chunk in arquivo.chunks():
                    destino.write(chunk)

            importar_planilha('temp_planilha.xlsx')
            return redirect('listar_itens')

    return render(request, 'triagem/upload.html')


@login_required
def listar_itens_triados(request):
    itens = ItemTriado.objects.all().order_by('-data_importacao')
    return render(request, 'triagem/lista_itens.html', {'itens': itens})


@login_required
def validar_item(request, item_id):
    item = get_object_or_404(ItemTriado, id=item_id)

    if request.method == 'POST':
        item.grupo = request.POST.get('grupo', '')
        item.subgrupo = request.POST.get('subgrupo', '')
        item.objeto = request.POST.get('objeto', '')
        item.marca = request.POST.get('marca', '')
        item.fabricante = request.POST.get('fabricante', '')
        item.unidade_medida = request.POST.get('unidade_medida', '')
        item.campo_dinamico_1 = request.POST.get('campo_dinamico_1', '')
        item.campo_dinamico_2 = request.POST.get('campo_dinamico_2', '')
        item.responsavel_triagem = request.user.username
        item.save()
        return redirect('listar_itens')

    return render(request, 'triagem/validar_item.html', {'item': item})


@login_required
def gerar_cotacao(request):
    itens = ItemTriado.objects.filter(
        grupo__isnull=False
    ).exclude(grupo='').order_by('grupo', 'subgrupo')

    if not itens.exists():
        return HttpResponse("Nenhum item validado para gerar cotação.")

    # Cria a cotação no banco
    cotacao = Cotacao.objects.create(usuario=request.user)

    # Salva os itens da cotação
    for item in itens:
        ItemCotado.objects.create(cotacao=cotacao, item_triagem=item)

    # Gera a planilha Excel
    dados = []
    for item in itens:
        dados.append({
            'Descrição': item.descricao,
            'Unidade': item.unidade,
            'Quantidade': item.quantidade,
            'Grupo': item.grupo,
            'Subgrupo': item.subgrupo,
            'Objeto': item.objeto,
            'Marca': item.marca,
            'Fabricante': item.fabricante,
            'Unidade de Medida': item.unidade_medida,
            'Campo 1': item.campo_dinamico_1,
            'Campo 2': item.campo_dinamico_2,
            'Responsável': item.responsavel_triagem,
        })

    df = pd.DataFrame(dados)
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="cotacao_{cotacao.numero}.xlsx"'
    df.to_excel(response, index=False)

    return response
