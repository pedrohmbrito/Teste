from django.urls import path
from django.contrib.auth.decorators import login_required
from .views import (
    upload_planilha,
    listar_itens_triados,
    validar_item,
    gerar_cotacao
)

urlpatterns = [
    path('upload/', login_required(upload_planilha), name='upload_planilha'),
    path('itens/', login_required(listar_itens_triados), name='listar_itens'),
    path('validar/<int:item_id>/', login_required(validar_item), name='validar_item'),
    path('cotacao/download/', login_required(gerar_cotacao), name='gerar_cotacao'),
]
