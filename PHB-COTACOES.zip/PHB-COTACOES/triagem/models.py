from django.db import models

class ItemTriado(models.Model):
    descricao = models.TextField()
    unidade = models.CharField(max_length=20)
    quantidade = models.DecimalField(max_digits=10, decimal_places=2)

    grupo = models.CharField(max_length=100, blank=True)
    subgrupo = models.CharField(max_length=100, blank=True)
    objeto = models.CharField(max_length=255, blank=True)
    marca = models.CharField(max_length=100, blank=True)
    fabricante = models.CharField(max_length=100, blank=True)
    unidade_medida = models.CharField(max_length=50, blank=True)

    campo_dinamico_1 = models.CharField(max_length=100, blank=True, null=True)
    campo_dinamico_2 = models.CharField(max_length=100, blank=True, null=True)

    responsavel_triagem = models.CharField(max_length=100, blank=True)

    data_importacao = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.descricao[:50]}..."
