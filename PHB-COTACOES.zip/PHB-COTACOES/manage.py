#!/usr/bin/env python
import os
import sys

def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "phb_cotacoes.settings")

    try:
        from django.core.management import execute_from_command_line
    except ImportError:
        # Se o Django não estiver instalado, levanta um erro amigável
        raise ImportError(
            "Não foi possível importar o Django. Certifique-se de que o Django está instalado e o ambiente está ativado."
        )

    execute_from_command_line(sys.argv)

if __name__ == "__main__":
    main()
